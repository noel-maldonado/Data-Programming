# (Guess the capitals) Rewrite Exercise 11.40 using a dictionary to store the pairs
# of states and capitals so that the questions are randomly displayed.

