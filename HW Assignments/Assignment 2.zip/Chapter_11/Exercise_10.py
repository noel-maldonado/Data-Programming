# (Largest rows and columns) Write a program that randomly fills in 0s and 1s into
# a matrix, prints the matrix, and finds the rows and columns with the most
# 1s. Here is a sample run of the program:
# 0011
# 0011
# 1101
# 1010
# The largest row index: 2
# The largest column index: 2, 3

import random


