# (Algebra: add two matrices) Write a function to add two matrices. The header of
# the function is:
# def addMatrix(a, b):
# In order to be added, the two matrices must have the same dimensions and the
# same or compatible types of elements. Let c be the resulting matrix. Each element
# cij is aij + bij.

# Write a test program that prompts the user to enter two matrices and displays
# their sum.

